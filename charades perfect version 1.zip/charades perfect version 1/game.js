// ========= Charades Game Engine =========

// 9 categories and their words
const CATEGORIES = {
  "Netflix and HBO Max": [
    "Stranger Things",
    "The Witcher",
    "Wednesday",
    "One Piece",
    "Queen's Gambit",
    "Love, Death & Robots",
    "Devil May Cry",
    "Alice in Borderland",
    "Castlevania",
    "Squid Game",
    "Black Mirror",
    "Peaky Blinders",
    "Lucifer",
    "Money Heist",
    "The Umbrella Academy",
    "Sex Education",
    "The Sandman",
    "Arcane",
    "Cobra Kai",
    "The Crown",
    "Narcos",
    "Lupin",
    "Bridgerton",
    "The Haunting of Hill House",
    "Ozark",
    "The Mandalorian",
    "Sex and the City",
    "Game of Thrones",
    "Euphoria",
    "Westworld",
    "Big Little Lies",
    "True Detective",
  ],
  
  "90's Love Songs": [
    "I Will Always Love You - Whitney Houston",
    "End of the Road - Boyz II Men",
    "My Heart Will Go On - Celine Dion",
    "Vision of Love - Mariah Carey",
    "Because You Loved Me - Celine Dion",
    "I Don't Want to Miss a Thing - Aerosmith",
    "Kiss from a Rose - Seal",
    "Un-Break My Heart - Toni Braxton",
    "I'll Make Love to You - Boyz II Men",
    "More Than Words - Extreme",
    "Baby One More Time - Britney Spears",
    "Always Be My Baby - Mariah Carey",
    "Tears in Heaven - Eric Clapton",
    "When You Say Nothing at All - Ronan Keating",
    "Have I Told You Lately - Rod Stewart",
    "I Swear - All-4-One",
    "All My Life - K-Ci & JoJo",
    "Truly Madly Deeply - Savage Garden",
    "Iris - Goo Goo Dolls",
    "I'll Be There for You - Bon Jovi",
    "It must have been love - Roxette",
    "To Be with You - Mr. Big",
    "Hero - Enrique Iglesias",
    "Everything I Do - Bryan Adams",
    "More Than a Feeling - Boston",
 
  ],

  "Horror Movies": [
    "The Grudge",
    "It",
    "The Conjuring",
    "A Nightmare on Elm Street",
    "Halloween",
    "The Exorcist",
    "Hereditary",
    "The Ring",
    "Insidious",
    "Scream",
    "Psycho",
    "The Babadook",
    "Get Out",
    "The Blair Witch Project",
    "Paranormal Activity",
    "Carrie",
    "The Texas Chainsaw Massacre",
    "Child's Play",
    "Annabelle",
    "The Cabin in the Woods",
    "The Omen",
    "28 Days Later",
    "The Descent",
    "Saw",
    "The Witch",
    "It Follows",
    
  ],

  "2000's Hit Songs": [
    "What a Girl Wants - Christina Aguilera",
    "Hips Don't Lie - Shakira",
    "Since U Been Gone - Kelly Clarkson",
    "Crazy in Love - Beyoncé",
    "Umbrella - Rihanna",
    "Toxic - Britney Spears",
    "Hey Ya! - OutKast",
    "In Da Club - 50 Cent",
    "I Gotta Feeling - The Black Eyed Peas",
    "Single Ladies - Beyoncé",
    "Gold Digger - Kanye West",
    "Poker Face - Lady Gaga",
    "Mr. Brightside - The Killers",
    "Irreplaceable - Beyoncé",
    "SexyBack - Justin Timberlake",
    "Rehab - Amy Winehouse",
    "Boulevard of Broken Dreams - Green Day",
    "Viva La Vida - Coldplay",
    "Drop It Like It's Hot - Snoop Dogg",
    "Fireflies - Owl City",
    "Bleeding Love - Leona Lewis",
    "Apologize - OneRepublic",
    "Bad Romance - Lady Gaga",
    "Clocks - Coldplay",
  
  ],

  "OPM Hits": [
    "Tadhana - Up Dharma Down",
    "Buwan - JK Labajo",
    "Ikaw - Yeng Constantino",
    "Kahit Ayaw Mo Na - This Band", 
    "Tagpuan - Moira Dela Torre",
    "Hanggang Kailan - Orange and Lemons",
    "Mundo - IV of Spades",
    "Huling Sayaw - Kamikazee",
    "Torete - Moonstar88",
    "Narda - Kamikazee",
    "Ligaya - Eraserheads",
    "214 - Rivermaya",
    "Di Na Mababawi - Sponge Cola",
    "Sundo - Imago",
    "Himala - Rivermaya",
    "With A Smile - Eraserheads",
    "Harana - Parokya ni Edgar", 
    "Panaginip - Hale",
    "Kisapmata - Rivermaya",
    "Salamat - The Dawn",
    "Huwag Ka Lang Mawawala - Ogie Alcasid",
    "Pusong Bato - Aimee Torres",
    "Akin Ka Na Lang - Morissette",
    "Tuloy Pa Rin - Neocolours",
    "Sana - I Belong to the Zoo",
    "Catch Me, I'm Falling - Kitchie Nadal",
    "Ligaw Tingin - December Avenue",
    "Hanggang - Wency Cornejo",
    "Bilog - Jireh Lim",
    "Sa'yo - Silent Sanctuary",
    "Kathang Isip - Ben&Ben",
    "Kung 'Di Rin Lang Ikaw - December Avenue feat. Moira Dela Torre",
    "Mahal Pa Rin Kita - Rockstar",

  ],

  "Sikat na Tagalog Movies": [
    "Hello, Love, Goodbye",
    "Four Sisters and a Wedding",
    "The Hows of Us",
    "That Thing Called Tadhana",
    "Kita Kita",
    "One More Chance",
    "Ang Babae sa Septic Tank",
    "Starting Over Again",
    "My Ex and Whys",
    "Barcelona: A Love Untold",
    "The Mistress",
    "Paano Kita Iibigin",
    "Milan",
    "Crying Ladies",
    "Bakit Hindi Ka Crush ng Crush Mo",
    "Camp Sawi",
    "My Amnesia Girl",
    "All of You",
    "The Achy Breaky Hearts",
    "Oro, Plata, Mata",
    "Himala",
    "Magnifico",
    "Tanging Yaman",
    "Dekada '70",
    "Bata, Bata... Pa'no Ka Ginawa?",
    "Muro Ami",
    "Bagets",
    "Sana Maulit Muli",
    "Anak",
    "Tanging Ina",
    "Ganito Kami Noon, Paano Kayo Ngayon",
    "Ang Pagdadalaga ni Maximo Oliveros",
    "Ligaya ang Itawag Mo sa Akin",
    "Kay Tagal Kitang Hinihintay",
    "Miss You Like Crazy",
    "Minsan Lang Kita Iibigin",
    "Mula sa Puso",
  ],

  "Stories and Mga Kwento": [
    "Pride and Prejudice",
    "To Kill a Mockingbird",
    "Noli Me Tangere",
    "El Filibusterismo",
    "The Great Gatsby",
    "1984",
    "Brave New World",
    "The Catcher in the Rye",
    "Dekada '70",
    "The Alchemist",
    "Banaag at Sikat",
    "Para kay B", 
    "Florante at Laura",
    "Ibong Adarna",
    "Wuthering Heights",
    "Jack and the Beanstalk",
    "Cinderella",
    "The Little Mermaid",
    "Hansel and Gretel",
    "The Ugly Duckling",
    "The Tortoise and the Hare",
    "The Three Little Pigs",
    "Little Red Riding Hood",
    "Sleeping Beauty",
    "Snow White and the Seven Dwarfs",
    "Rapunzel",
    "The Frog Prince",
    "Beauty and the Beast",
    "The Princess and the Pea",
    "Goldilocks and the Three Bears",
    "The Emperor's New Clothes",
    "Lola Basyang",
    "Alamat ng Pinya",
    "Alamat ng Ibong Adarna",
    "Alamat ng Bulkang Mayon",
    "Alamat ng Bahaghari",
    "Alamat ng Sampaguita",
    "Alamat ng Taal",
    "Alamat ng Niyog",
    "Alamat ng Mangga",
    "Alamat ng Duhat",
    "Alamat ng Saging",
    "Alamat ng Kawayan",
    "Magkaibigan ang Diwa at Luningning",
    "Ang Mabait na Kalabaw",
    "Si Pagong at si Matsing",
    "Ang Langgam at ang Tipaklong",
    "Malakas at Maganda",
    "Ang Alamat ng Ampalaya",
    "Si Pilandok at ang Manok na Bughaw",
    "Si Juan Tamad",
    "Ang Pagong at ang Matsing",
    "Ang Alamat ng Rosas",
  
  ],

  "Idioms (English)": [
    "A bird in the hand is worth two in the bush",
    "Actions speak louder than words",
    "Barking up the wrong tree",
    "Better late than never",
    "Don't count your chickens before they hatch",
    "Every cloud has a silver lining",
    "Hit the nail on the head",
    "Let the cat out of the bag",
    "Once in a blue moon",
    "The ball is in your court",
    "When in Rome, do as the Romans do",
    "A picture is worth a thousand words",
    "Curiosity killed the cat",
    "Don't put all your eggs in one basket",
    "Easy come, easy go",
    "Kill two birds with one stone",
    "The early bird catches the worm",
    "You can't judge a book by its cover",
    "Blood is thicker than water",
    "The pen is mightier than the sword",
    "Rome wasn't built in a day",
    "The squeaky wheel gets the grease",
    "Two heads are better than one",
    "You can't have your cake and eat it too",
    "A watched pot never boils",
    "Bite the bullet",
    "Break the ice",
    "Burn the midnight oil",
    "By the skin of your teeth",
    "Cut to the chase",
    "Devil's advocate",
    "Don't cry over spilled milk",
    "Every dog has its day",
    "Get a taste of your own medicine",
    "Give the benefit of the doubt",
    "Go the extra mile",
    
  ],

  "Mga Kasabihan": [
    "Mababaw ang luha",
    "Nasa Diyos ang awa, nasa tao ang gawa",
    "Pag may tiyaga, may nilaga",
    "Huwag magbilang ng sisiw hangga't hindi pa napipisa ang itlog",
    "Kung ano ang itinanim, siya rin ang aanihin",
    "Walang mahirap sa taong may tiyaga",
    "Ang hindi marunong lumingon sa pinanggalingan ay hindi makararating sa paroroonan",
    "Kapag may isinuksok, may madudukot",
    "Pagkahaba-haba man ng prusisyon, sa simbahan din ang tuloy",
    "Aanhin pa ang damo kung patay na ang kabayo",
    "Kung may usok, may apoy",
    "Pag-ibig na walang pagsubok, parang kape na walang gatas",
    "Ang taong nagigipit, sa patalim kumakapit",
    "Nasa huli ang pagsisisi",
    "Kung walang tiyaga, walang nilaga",
    "Ang buhay ay parang gulong, minsan nasa ibabaw, minsan nasa ilalim",
    "Walang sinuman ang nabubuhay para sa sarili lamang",
    "Ang taong nagigipit, kahit sa patalim kumakapit",
    "Kung ano ang puno, siya ang bunga",
    "Ang taong walang kibo, nasa loob ang kulo",
    "Pag may sinuksok, may madudukot",
  ],

};

const STORAGE_KEY = "charadesState";

// Shared state across all tabs
let state = loadInitialState();

// Timer only runs on admin tab
let adminTimerId = null;

// BroadcastChannel to sync tabs quickly
let channel = null;
if ("BroadcastChannel" in window) {
  channel = new BroadcastChannel("charades-game");
  channel.onmessage = (event) => {
    const msg = event.data;
    if (!msg || msg.type !== "state") return;
    state = msg.payload;
    renderForCurrentPage();
  };
}

// Fallback sync via localStorage
window.addEventListener("storage", (e) => {
  if (e.key !== STORAGE_KEY || !e.newValue) return;
  try {
    state = JSON.parse(e.newValue);
    renderForCurrentPage();
  } catch {
    // ignore
  }
});

// ---------- State helpers ----------

function defaultPlayers() {
  return [
    { id: 0, name: "Player 1", score: 0 },
    { id: 1, name: "Player 2", score: 0 },
    { id: 2, name: "Player 3", score: 0 },
    { id: 3, name: "Player 4", score: 0 },
  ];
}

function normalizePlayers(players) {
  const base = Array.isArray(players) ? players.slice(0, 4) : [];
  const result = [];
  for (let i = 0; i < 4; i++) {
    const p = base[i] || {};
    result.push({
      id: i,
      name: p.name || `Player ${i + 1}`,
      score: Number.isFinite(p.score) ? p.score : 0,
    });
  }
  return result;
}

function loadInitialState() {
  const blank = {
    players: defaultPlayers(),
    currentPlayerIndex: 0,
    category: null,
    words: [],
    guessed: [],
    roundActive: false,
    roundPrepared: false, // words shown, timer not started yet
    timeRemaining: 0,
    roundId: 0,
    bannerDataUrl: null, // for uploaded banner
    forceAudienceSplash: false, // manual splash toggle
  };

  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return blank;

  try {
    const saved = JSON.parse(raw);
    const merged = { ...blank, ...saved };
    merged.players = normalizePlayers(merged.players);
    merged.currentPlayerIndex = clamp(merged.currentPlayerIndex, 0, 3);
    merged.words = Array.isArray(merged.words) ? merged.words.slice(0, 5) : [];
    merged.guessed = Array.isArray(merged.guessed)
      ? merged.guessed.slice(0, merged.words.length).map(Boolean)
      : [];
    if (merged.guessed.length !== merged.words.length) {
      merged.guessed = merged.words.map(() => false);
    }
    merged.roundActive = !!merged.roundActive;
    merged.roundPrepared = !!merged.roundPrepared;
    merged.timeRemaining = Number.isFinite(merged.timeRemaining) ? merged.timeRemaining : 0;
    merged.roundId = merged.roundId || 0;
    merged.bannerDataUrl = merged.bannerDataUrl || null;
    merged.forceAudienceSplash = !!merged.forceAudienceSplash;
    return merged;
  } catch {
    return blank;
  }
}

function saveAndBroadcastState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  if (channel) {
    channel.postMessage({ type: "state", payload: state });
  }
}

function clamp(value, min, max) {
  const v = Number(value) || 0;
  return Math.min(max, Math.max(min, v));
}

function formatTime(seconds) {
  const s = Math.max(0, Math.floor(seconds));
  const mm = String(Math.floor(s / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

// generic sound helper used by soundboard + correct sound
function playFx(audioId) {
  const el = document.getElementById(audioId);
  if (!el) return;
  try {
    el.currentTime = 0;
    el.play().catch(() => {
      // ignore autoplay errors
    });
  } catch {
    // ignore
  }
}

function getRandomWordsFromCategory(category, count = 5) {
  const poolSrc = CATEGORIES[category];
  if (!poolSrc || !poolSrc.length) return [];
  const pool = [...poolSrc];
  const out = [];
  while (pool.length && out.length < count) {
    const idx = Math.floor(Math.random() * pool.length);
    out.push(pool.splice(idx, 1)[0]);
  }
  return out;
}

function getCurrentPlayer() {
  return state.players[state.currentPlayerIndex] || {
    name: `Player ${state.currentPlayerIndex + 1}`,
    score: 0,
  };
}

// ---------- Round lifecycle (prepare words / start game / end game) ----------

function prepareRound(category) {
  if (!category) {
    alert("Please select a category first (on the Player screen).");
    return;
  }
  if (state.roundActive) {
    alert("End the current round before preparing new words.");
    return;
  }

  const words = getRandomWordsFromCategory(category, 5);
  if (!words.length) {
    alert(`No words in category "${category}". Add some in game.js.`);
    return;
  }

  state.category = category;
  state.words = words;
  state.guessed = words.map(() => false);
  state.roundActive = false;
  state.roundPrepared = true; // words are visible, timer not started
  state.timeRemaining = 0;

  saveAndBroadcastState();
  renderForCurrentPage();
}

function startGame(durationSeconds, fallbackCategory) {
  if (state.roundActive) {
    return;
  }

  const categoryToUse = state.category || fallbackCategory;
  if (!categoryToUse) {
    alert("Please select a category first (on the Player screen).");
    return;
  }

  if (!state.words || !state.words.length || state.category !== categoryToUse) {
    const words = getRandomWordsFromCategory(categoryToUse, 5);
    if (!words.length) {
      alert(`No words in category "${categoryToUse}". Add some in game.js.`);
      return;
    }
    state.category = categoryToUse;
    state.words = words;
  }

  state.guessed = state.words.map(() => false);

  state.timeRemaining = durationSeconds;
  state.roundActive = true;
  state.roundPrepared = false;
  state.roundId = (state.roundId || 0) + 1;

  saveAndBroadcastState();
  startAdminTimer();
  renderForCurrentPage();
}

// ---------- Admin logic ----------

function initAdminPage() {
  const categorySelect = document.getElementById("categorySelect");
  const currentPlayerSelect = document.getElementById("currentPlayerSelect");
  const roundDurationInput = document.getElementById("roundDuration");
  const showWordsBtn = document.getElementById("showWordsBtn");
  const newWordsBtn = document.getElementById("newWordsBtn");
  const startBtn = document.getElementById("startRoundBtn");
  const endBtn = document.getElementById("endRoundBtn");
  const resetScoresBtn = document.getElementById("resetScoresBtn");
  const restartGameBtn = document.getElementById("restartGameBtn");
  const wordsList = document.getElementById("adminWordsList");
  const bannerUpload = document.getElementById("bannerUpload");
  const showSplashBtn = document.getElementById("showSplashBtn");
  const showGameBtn = document.getElementById("showGameBtn");

  // soundboard buttons
  const btnAllWinner = document.getElementById("btnAllWinner");
  const btnAudienceClap = document.getElementById("btnAudienceClap");
  const btnBuzzMe = document.getElementById("btnBuzzMe");
  const btnCountdown = document.getElementById("btnCountdown");
  const btnHeartbeat = document.getElementById("btnHeartbeat");
  const btnWrongBuzz = document.getElementById("btnWrongBuzz");

  // Populate categories in the (now read-only) select
  if (categorySelect) {
    categorySelect.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "— Category chosen by player —";
    categorySelect.appendChild(placeholder);

    Object.keys(CATEGORIES).forEach((cat) => {
      const opt = document.createElement("option");
      opt.value = cat;
      opt.textContent = cat;
      categorySelect.appendChild(opt);
    });
  }

  // Hook up player name inputs
  for (let i = 0; i < 4; i++) {
    const input = document.getElementById(`playerName${i}`);
    if (!input) continue;
    const player = state.players[i];
    input.value = player.name;
    input.addEventListener("input", () => {
      state.players[i].name = input.value.trim() || `Player ${i + 1}`;
      saveAndBroadcastState();
      renderAdminPage();
    });
  }

  // Current player select
  currentPlayerSelect.value = String(state.currentPlayerIndex);
  currentPlayerSelect.addEventListener("change", () => {
    const idx = clamp(currentPlayerSelect.value, 0, 3);
    state.currentPlayerIndex = idx;
    saveAndBroadcastState();
    renderAdminPage();
  });

  // Banner upload
  if (bannerUpload) {
    bannerUpload.addEventListener("change", (event) => {
      const file = event.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        state.bannerDataUrl = e.target.result;
        saveAndBroadcastState();
        renderAdminPage();
      };
      reader.readAsDataURL(file);
    });
  }

  // Audience splash manual control
  if (showSplashBtn) {
    showSplashBtn.addEventListener("click", () => {
      state.forceAudienceSplash = true;
      saveAndBroadcastState();
      renderAdminPage();
    });
  }

  if (showGameBtn) {
    showGameBtn.addEventListener("click", () => {
      state.forceAudienceSplash = false;
      saveAndBroadcastState();
      renderAdminPage();
    });
  }

  // SHOW PLAYER WORDS (preview, no timer, also set active player)
  showWordsBtn.addEventListener("click", () => {
    const idx = clamp(currentPlayerSelect.value, 0, 3);
    state.currentPlayerIndex = idx;
    saveAndBroadcastState(); // update player name on all screens

    const cat = state.category;
    if (!cat) {
      alert("Ask the player to choose a category on their screen first.");
      return;
    }
    prepareRound(cat);
  });

  // NEW WORDS (reroll words for same category)
  newWordsBtn.addEventListener("click", () => {
    const cat = state.category;
    if (!cat) {
      alert("Ask the player to choose a category on their screen first.");
      return;
    }
    prepareRound(cat);
  });

  // START GAME (start timer, use player's current category)
  startBtn.addEventListener("click", () => {
    let duration = parseInt(roundDurationInput.value, 10);
    if (Number.isNaN(duration) || duration <= 0) {
      duration = 60;
      roundDurationInput.value = "60";
    }
    const cat = state.category;
    if (!cat) {
      alert("Ask the player to choose a category on their screen first.");
      return;
    }
    startGame(duration, cat);
  });

  // End round button
  endBtn.addEventListener("click", () => {
    endCurrentRound();
  });

  // Reset scores only
  resetScoresBtn.addEventListener("click", () => {
    if (!confirm("Reset all scores to 0?")) return;
    state.players.forEach((p) => (p.score = 0));
    saveAndBroadcastState();
    renderAdminPage();
  });

  // Restart whole game (scores + round state, keep banner & names)
  restartGameBtn.addEventListener("click", () => {
    if (!confirm("Restart game? This will clear all scores and current round.")) return;
    restartGame();
  });

  // Word click: toggle guessed / score (only during active rounds)
  wordsList.addEventListener("click", (e) => {
    const btn = e.target.closest("button[data-word-index]");
    if (!btn) return;
    const idx = parseInt(btn.dataset.wordIndex, 10);
    if (Number.isNaN(idx)) return;
    toggleWordGuessed(idx);
  });

  // Soundboard wiring
  if (btnAllWinner) btnAllWinner.addEventListener("click", () => playFx("sndAllWinner"));
  if (btnAudienceClap) btnAudienceClap.addEventListener("click", () => playFx("sndAudienceClap"));
  if (btnBuzzMe) btnBuzzMe.addEventListener("click", () => playFx("sndBuzzMe"));
  if (btnCountdown) btnCountdown.addEventListener("click", () => playFx("sndCountdown"));
  if (btnHeartbeat) btnHeartbeat.addEventListener("click", () => playFx("sndHeartbeat"));
  if (btnWrongBuzz) btnWrongBuzz.addEventListener("click", () => playFx("sndWrongBuzz"));

  // If a round is active, resume timer
  if (state.roundActive && state.timeRemaining > 0) {
    startAdminTimer();
  }

  renderAdminPage();
}

function startAdminTimer() {
  if (adminTimerId) {
    clearInterval(adminTimerId);
    adminTimerId = null;
  }

  adminTimerId = setInterval(() => {
    if (!state.roundActive) {
      clearInterval(adminTimerId);
      adminTimerId = null;
      return;
    }
    state.timeRemaining = Math.max(0, (state.timeRemaining || 0) - 1);
    if (state.timeRemaining === 0) {
      state.roundActive = false;
      saveAndBroadcastState();
      clearInterval(adminTimerId);
      adminTimerId = null;
    } else {
      saveAndBroadcastState();
    }
    renderAdminTimerOnly();
  }, 1000);
}

function endCurrentRound() {
  state.roundActive = false;
  state.roundPrepared = false;
  state.timeRemaining = 0;
  saveAndBroadcastState();
  if (adminTimerId) {
    clearInterval(adminTimerId);
    adminTimerId = null;
  }
  renderAdminPage();
}

function restartGame() {
  if (adminTimerId) {
    clearInterval(adminTimerId);
    adminTimerId = null;
  }

  state.players = state.players.map((p, idx) => ({
    id: idx,
    name: p.name || `Player ${idx + 1}`,
    score: 0,
  }));
  state.currentPlayerIndex = 0;
  state.category = null;
  state.words = [];
  state.guessed = [];
  state.roundActive = false;
  state.roundPrepared = false;
  state.timeRemaining = 0;
  state.roundId = 0;
  state.forceAudienceSplash = false;
  // keep bannerDataUrl

  saveAndBroadcastState();
  renderAdminPage();
}

// Only allow scoring during an active round
function toggleWordGuessed(index) {
  if (!state.roundActive) return;
  if (!state.words || !state.words[index]) return;
  if (!state.guessed || state.guessed.length !== state.words.length) {
    state.guessed = state.words.map(() => false);
  }

  // How many were correct before this click?
  const prevCorrectCount = state.guessed.filter(Boolean).length;

  const previouslyGuessed = !!state.guessed[index];
  const nowGuessed = !previouslyGuessed;
  state.guessed[index] = nowGuessed;

  const player = getCurrentPlayer();
  if (nowGuessed) {
    player.score += 1;
    // 🔊 per-word correct sound
    playFx("correctSound");
  } else {
    player.score = Math.max(0, player.score - 1);
  }

  state.players[state.currentPlayerIndex].score = player.score;

  // How many are correct after this click?
  const newCorrectCount = state.guessed.filter(Boolean).length;

  // If we just reached "all correct", play the ALL WINNER sound once
  if (
    state.words.length > 0 &&
    newCorrectCount === state.words.length &&       // now all correct
    prevCorrectCount !== state.words.length        // but not all before
  ) {
    playFx("sndAllWinner");
  }

  saveAndBroadcastState();
  renderAdminPage();
}


// ---------- Rendering helpers ----------

function renderScoreboard(containerId, mode) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = "";

  const players = state.players || [];
  players.forEach((p, index) => {
    const row = document.createElement("div");
    row.className = "score-row";
    if (index === state.currentPlayerIndex) {
      row.classList.add("active");
    }

    const name = document.createElement("div");
    name.className = "score-name";
    name.textContent = p.name || `Player ${index + 1}`;

    const value = document.createElement("div");
    value.className = "score-value";
    value.textContent = p.score ?? 0;

    row.appendChild(name);
    row.appendChild(value);
    el.appendChild(row);
  });
}

function renderAdminBannerPreview() {
  const preview = document.getElementById("adminBannerPreview");
  if (!preview) return;
  if (state.bannerDataUrl) {
    preview.src = state.bannerDataUrl;
    preview.style.display = "block";
  } else {
    preview.src = "";
    preview.style.display = "none";
  }
}

// ---------- Page-specific renderers ----------

function renderAdminPage() {
  const catEl = document.getElementById("adminCategoryDisplay");
  const timerEl = document.getElementById("adminTimer");
  const statusEl = document.getElementById("adminStatus");
  const currentPlayerEl = document.getElementById("adminCurrentPlayer");
  const categorySelect = document.getElementById("categorySelect");
  const currentPlayerSelect = document.getElementById("currentPlayerSelect");
  const startBtn = document.getElementById("startRoundBtn");
  const endBtn = document.getElementById("endRoundBtn");
  const showSplashBtn = document.getElementById("showSplashBtn");
  const showGameBtn = document.getElementById("showGameBtn");

  if (!catEl || !timerEl || !statusEl) return;

  const currentPlayer = getCurrentPlayer();

  // Update dropdown labels
  for (let i = 0; i < 4; i++) {
    const opt = document.getElementById(`currentPlayerOption${i}`);
    if (opt && state.players[i]) {
      opt.textContent = state.players[i].name || `Player ${i + 1}`;
    }
  }
  currentPlayerSelect.value = String(state.currentPlayerIndex);

  // Sync category select with state & disable (read-only)
  if (categorySelect) {
    if (state.category && CATEGORIES[state.category]) {
      categorySelect.value = state.category;
    } else {
      categorySelect.value = "";
    }
    categorySelect.disabled = true;
  }

  currentPlayerEl.textContent = currentPlayer.name;
  catEl.textContent = state.category || "—";
  timerEl.textContent = formatTime(state.timeRemaining || 0);

  if (state.roundActive) {
    statusEl.textContent = "Round in progress… Click words that were guessed correctly.";
    statusEl.style.color = "var(--accent-admin)";
    startBtn.disabled = true;
    endBtn.disabled = false;
  } else if (state.roundPrepared && state.words && state.words.length) {
    statusEl.textContent = "Words are shown to the player. Click Start Game to begin the timer.";
    statusEl.style.color = "var(--text-muted)";
    startBtn.disabled = false;
    endBtn.disabled = true;
  } else if (state.words && state.words.length) {
    statusEl.textContent = "Round finished. Prepare new words or switch to the next player.";
    statusEl.style.color = "var(--text-muted)";
    startBtn.disabled = false;
    endBtn.disabled = true;
  } else {
    statusEl.textContent = "Waiting for the player to choose a category.";
    statusEl.style.color = "var(--text-muted)";
    startBtn.disabled = false;
    endBtn.disabled = true;
  }

  renderAdminWordsList();
  renderScoreboard("adminScoreboard", "admin");
  renderAdminBannerPreview();

  if (showSplashBtn && showGameBtn) {
    showSplashBtn.disabled = !!state.forceAudienceSplash;
    showGameBtn.disabled = !state.forceAudienceSplash;
  }
}

function renderAdminTimerOnly() {
  const timerEl = document.getElementById("adminTimer");
  const statusEl = document.getElementById("adminStatus");
  if (!timerEl) return;
  timerEl.textContent = formatTime(state.timeRemaining || 0);
  if (!state.roundActive && (state.timeRemaining || 0) === 0 && statusEl) {
    statusEl.textContent = "Time's up! Mark final correct words if needed.";
    statusEl.style.color = "var(--danger)";
  }
}

function renderAdminWordsList() {
  const list = document.getElementById("adminWordsList");
  if (!list) return;
  list.innerHTML = "";

  if (!state.words || !state.words.length) {
    const li = document.createElement("li");
    li.className = "word-list-empty";
    li.textContent = "No words yet. Ask the player to pick a category, then click “Show Player Words”.";
    list.appendChild(li);
    return;
  }

  const guessedArr =
    Array.isArray(state.guessed) && state.guessed.length === state.words.length
      ? state.guessed
      : state.words.map(() => false);

  state.words.forEach((word, index) => {
    const li = document.createElement("li");
    li.className = "word-item";
    if (guessedArr[index]) {
      li.classList.add("guessed");
    }

    const span = document.createElement("span");
    span.className = "word-text";
    span.textContent = word;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-sm btn-toggle";
    btn.dataset.wordIndex = String(index);
    btn.textContent = guessedArr[index] ? "✓ Correct" : "Mark correct";

    li.appendChild(span);
    li.appendChild(btn);
    list.appendChild(li);
  });
}

function renderAudiencePage() {
  const splashSection = document.getElementById("audienceSplash");
  const gameSection = document.getElementById("audienceGame");
  const catEl = document.getElementById("audienceCategory");
  const timerEl = document.getElementById("audienceTimer");
  const statusEl = document.getElementById("audienceStatus");
  const currentPlayerEl = document.getElementById("audienceCurrentPlayer");
  const guessedListEl = document.getElementById("audienceGuessedWords");
  const noWordsMsgEl = document.getElementById("audienceNoWordsMsg");
  const bannerSplash = document.getElementById("audienceBannerSplash");
  const bannerGame = document.getElementById("audienceBannerGame");

  if (!catEl || !timerEl || !statusEl || !currentPlayerEl) return;

  // Reset status-ended class; we may re-add it below if round is over
  statusEl.classList.remove("status-ended");

  // Decide when to show splash
  const noWords = !state.words || state.words.length === 0;
  const forceSplash = !!state.forceAudienceSplash;
  const showSplash = forceSplash || (!state.roundActive && !state.roundPrepared && noWords);

  if (splashSection && gameSection) {
    splashSection.style.display = showSplash ? "block" : "none";
    gameSection.style.display = showSplash ? "none" : "block";
  }

  // Set banner on both splash + game
  [bannerSplash, bannerGame].forEach((el) => {
    if (!el) return;
    if (state.bannerDataUrl) {
      el.src = state.bannerDataUrl;
      el.style.display = "block";
    } else {
      el.src = "";
      el.style.display = "none";
    }
  });

  const currentPlayer = getCurrentPlayer();

  currentPlayerEl.textContent = currentPlayer.name;
  catEl.textContent = state.category || "—";
  timerEl.textContent = formatTime(state.timeRemaining || 0);

  renderScoreboard("audienceScoreboard", "audience");

  const words = state.words || [];
  const guessedArr =
    Array.isArray(state.guessed) && state.guessed.length === words.length
      ? state.guessed
      : words.map(() => false);

  // ✅ Reveal all words AFTER the round has ended
  const roundEnded =
    state.roundId > 0 &&          // a real round has started before
    !state.roundActive &&         // round is not running
    !state.roundPrepared &&       // not in "Show Player Words" pre-round state
    words.length > 0 &&
    state.timeRemaining === 0;    // time is over or End Round pressed

  if (guessedListEl) {
    guessedListEl.innerHTML = "";

    if (roundEnded) {
      // Show ALL words: guessed (gold) + missed (dimmed)
      words.forEach((w, i) => {
        const li = document.createElement("li");
        li.className = "word-item";
        const span = document.createElement("span");
        span.className = "word-text";
        span.textContent = w;

        if (guessedArr[i]) {
          li.classList.add("guessed");
        } else {
          li.classList.add("missed");
        }

        li.appendChild(span);
        guessedListEl.appendChild(li);
      });
      if (noWordsMsgEl) noWordsMsgEl.style.display = "none";
    } else {
      // While round is running (or not yet finished), show ONLY guessed words
      const guessedWords = words.filter((w, i) => guessedArr[i]);
      if (guessedWords.length) {
        guessedWords.forEach((w) => {
          const li = document.createElement("li");
          li.className = "word-item guessed";
          const span = document.createElement("span");
          span.className = "word-text";
          span.textContent = w;
          li.appendChild(span);
          guessedListEl.appendChild(li);
        });
        if (noWordsMsgEl) noWordsMsgEl.style.display = "none";
      } else {
        if (noWordsMsgEl) noWordsMsgEl.style.display = "block";
      }
    }
  }

  // === Status message ===
  if (state.roundActive) {
    statusEl.textContent = "Guess the words based on the actor's charades!";
  } else if (state.roundPrepared && words.length) {
    statusEl.textContent = "Round about to start. Get ready!";
  } else if (roundEnded) {
    statusEl.textContent = "ROUND ENDED — Here are all the words this round.";
    statusEl.classList.add("status-ended");
  } else if (words.length) {
    statusEl.textContent = "Round finished. Wait for the next player.";
  } else {
    statusEl.textContent = "Waiting for the admin to start a round…";
  }
}


function renderPlayerCategoryChooser() {
  const container = document.getElementById("playerCategoryChooser");
  if (!container) return;

  container.innerHTML = "";

  // ✅ Player can change category anytime as long as the round is NOT running
  const canChoose = !state.roundActive;

  Object.keys(CATEGORIES).forEach((cat) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-outline category-btn";
    btn.textContent = cat;

    if (state.category === cat) {
      btn.classList.add("category-btn-active");
    }

    if (!canChoose) {
      btn.disabled = true;
    }

    btn.addEventListener("click", () => {
      if (!canChoose) return;

      // When changing category, clear any prepared words/state
      state.category = cat;
      state.words = [];
      state.guessed = [];
      state.roundActive = false;
      state.roundPrepared = false;
      state.timeRemaining = 0;

      saveAndBroadcastState();
      renderForCurrentPage();
    });

    container.appendChild(btn);
  });
}


function renderPlayerPage() {
  const nameEl = document.getElementById("playerCurrentName");
  const catEl = document.getElementById("playerCategory");
  const timerEl = document.getElementById("playerTimer");
  const statusEl = document.getElementById("playerStatus");
  const wordsListEl = document.getElementById("playerWordsList");

  if (!nameEl || !catEl || !timerEl || !statusEl) return;

  const currentPlayer = getCurrentPlayer();

  nameEl.textContent = currentPlayer.name;
  catEl.textContent = state.category || "—";
  timerEl.textContent = formatTime(state.timeRemaining || 0);

  renderPlayerCategoryChooser();

  const words = state.words || [];
  const guessedArr =
    Array.isArray(state.guessed) && state.guessed.length === words.length
      ? state.guessed
      : words.map(() => false);

  if (wordsListEl) {
    wordsListEl.innerHTML = "";
    if (!words.length) {
      const li = document.createElement("li");
      li.className = "word-list-empty";
      li.textContent =
        "Pick a category above. The admin will then show your 5 words.";
      wordsListEl.appendChild(li);
    } else {
      words.forEach((w, i) => {
        const li = document.createElement("li");
        li.className = "word-item";
        if (guessedArr[i]) {
          li.classList.add("guessed");
        }
        const span = document.createElement("span");
        span.className = "word-text";
        span.textContent = guessedArr[i] ? `✓ ${w}` : w;
        li.appendChild(span);
        wordsListEl.appendChild(li);
      });
    }
  }

  renderScoreboard("playerScoreboard", "player");

  // Clear any "ended" style; we'll add it only when truly ended
  statusEl.classList.remove("status-ended");

  if (!state.category) {
    statusEl.textContent = "Choose a category first, then wait for the admin to show your words.";
  } else if (!words.length) {
    statusEl.textContent = "Category chosen. Wait for the admin to show your words.";
  } else if (state.roundActive) {
    statusEl.textContent = "Act these words out! No speaking or sounds.";
  } else if (state.roundPrepared && !state.roundActive) {
    statusEl.textContent = "Memorize your words. Wait for the admin to start the game.";
  } else if (!state.roundActive && state.timeRemaining === 0) {
    statusEl.textContent = "ROUND ENDED — Check the audience screen for results.";
    statusEl.classList.add("status-ended");
  }

}

// Decide which render to call for current page
function renderForCurrentPage() {
  if (document.body.classList.contains("admin-page")) {
    renderAdminPage();
  } else if (document.body.classList.contains("audience-page")) {
    renderAudiencePage();
  } else if (document.body.classList.contains("player-page")) {
    renderPlayerPage();
  }
}

// ---------- Init ----------

document.addEventListener("DOMContentLoaded", () => {
  if (document.body.classList.contains("admin-page")) {
    initAdminPage();
  } else if (document.body.classList.contains("audience-page")) {
    renderAudiencePage();
  } else if (document.body.classList.contains("player-page")) {
    renderPlayerPage();
  }
});
